require("dotenv").config({ path: "./config.env" });

const mysql = require("mysql2");

/* ===== POOL ===== */
const pool = mysql.createPool({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  waitForConnections: true,
  connectionLimit: 10
});

/* ===== PROMISE WRAPPER ===== */
const promisePool = pool.promise();

/* ===== EXPORT ===== */
module.exports = {
  pool,
  query: (...args) => promisePool.query(...args)
};